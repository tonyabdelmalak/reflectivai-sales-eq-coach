import { loadEnv } from 'dotenv-local';
import express from 'express';
import { s as serverBefore, h as handler, a as serverAfter } from './bin/index-Dtzvnd9z.js';
import 'node:path';
import 'drizzle-orm/mysql2';
import 'mysql2/promise';
import 'node:fs';
import 'node:process';
import './bin/api/commerce/create-checkout-session/POST-BnIULVYh.js';
import './bin/api/download-fix/GET-B6KXAoum.js';
import 'fs';
import 'path';
import './bin/api/health/GET-CzFTnlth.js';
import './bin/api/probe-worker/GET-CaDPc_tv.js';

var server = express();
serverBefore?.(server);
var {
  HOST,
  PORT
} = loadEnv({
  envPrefix: "SERVER_",
  removeEnvPrefix: true,
  envInitial: {
    SERVER_HOST: "127.0.0.1",
    SERVER_PORT: "3000"
  }
});
var SERVER_URL = `http://${HOST}:${PORT}${"/"}`;
server.use("/api", handler);
server.use("/", express.static("client"));
serverAfter?.(server);
var PORT_NRO = parseInt(PORT);
server.listen(PORT_NRO, HOST, () => {
  console.log(`Ready at ${SERVER_URL}`);
}).on("error", (error) => {
  console.error(`Error at ${SERVER_URL}`, error);
});
