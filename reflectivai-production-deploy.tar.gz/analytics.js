// Analytics initialization
// C2 analytics loading is now managed by CookieBanner component
// to ensure GDPR/CCPA compliance with user consent.
// The script will only load after user accepts analytics cookies.
(window._signalsDataLayer=window._signalsDataLayer||[]);

