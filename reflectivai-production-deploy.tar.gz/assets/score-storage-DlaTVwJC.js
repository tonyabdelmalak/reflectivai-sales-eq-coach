const STORAGE_KEY = "reflectivai-roleplay-scores";
function saveRoleplayScores(scores, sessionId) {
  try {
    const data = {
      scores,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      sessionId
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    console.log("[SCORE_STORAGE] Saved roleplay scores:", data);
  } catch (err) {
    console.error("[SCORE_STORAGE] Failed to save scores:", err);
  }
}
function getLatestRoleplayScores() {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return null;
    const data = JSON.parse(stored);
    console.log("[SCORE_STORAGE] Loaded roleplay scores:", data);
    return data;
  } catch (err) {
    console.error("[SCORE_STORAGE] Failed to load scores:", err);
    return null;
  }
}
export {
  getLatestRoleplayScores,
  saveRoleplayScores
};
