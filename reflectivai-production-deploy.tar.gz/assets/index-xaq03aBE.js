const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/main-BsVSqTBl.js","assets/vendor-Ddyv8-Ua.js","assets/preload-Cg1PT9vB.js","assets/main-Nj8k1Suo.css"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-Cg1PT9vB.js";
__vitePreload(() => import("./main-BsVSqTBl.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
